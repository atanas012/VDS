CUDA_DEVICE_ORDER=PCI_BUS_ID LD_LIBRARY_PATH=./ ./miner --pool 47.243.32.3:9338 --user Vcg2cqAFbCH9ZLkFSzkpKDtvQAZzDhHdqi4.$rigName --algorithm vds --checkdifficulty $* 
